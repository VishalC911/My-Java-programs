package JavaLearning;

class Person {
	// Instance Varriables (Data or "State")
	String name;
	int age;
	
	
	//Classes can Contain
	
	//1. Data
	//2. Subroutines (Method)
	
	void speak() {
		System.out.println("My name is " + name + " and I am " + age + " years old");
	}

	 int calculateYearsToRetirment() {
		int yearsLeft = 65 - age;
		return yearsLeft;
	}
	 int getAge() {
		 return age;
	 }
	 
	 String getName()
	 {
		 return name;
	 }
	 
	
}

class Car {
	String color;
	int numOfDoors;
	int numOfWindows;
	
	void vroom() {
		System.out.println("I car go Vroom Vroom");
	}
	
}

public class ClassesandObjects {

	public static void main(String[] args)
	{
	Person person1 = new Person();
	person1.name = "Bob";
	person1.age = 5;
	person1.speak();
	int yearsBob = person1.calculateYearsToRetirment();
	System.out.println("Years til retirement" + yearsBob);
	
	Person person2 = new Person();
	person2.name = "Joe";
	person2.age = 10;
	person2.speak();
	int yearsJoe = person2.calculateYearsToRetirment();
	System.out.println("Years til retirement" + yearsJoe);
	
	Car car1 = new Car ();
	car1.color = "blue";
	car1.numOfDoors = 4;
	car1.numOfWindows = 4;
	car1.vroom();
	
	Car car2 = new Car ();
	car2.color = "green";
	car2.numOfDoors = 2;
	car2.numOfWindows = 2;
	car2.vroom();
	
	
	
	
	}

}
