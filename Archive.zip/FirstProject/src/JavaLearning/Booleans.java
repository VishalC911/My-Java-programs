package JavaLearning;

import java.util.Scanner;



public class Booleans {

	
	
	public static boolean isTeen (int age)
	{
		if (age > 11  && age <= 19)
		{
			return true;
		}
		
		else 
		{
			return false;
		}
		
	}
	
	public static void main(String[] args) 
	{
		int age;
	
		do 
		{
			System.out.println("please enter an age NOT A TEENAGER");
			Scanner input = new Scanner (System.in);
			age =  input.nextInt();
			} while (isTeen(age));
		
		System.out.println("Thank You");
	
	
	}
	

}
