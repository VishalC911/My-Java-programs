package JavaLearning;

class Machine {
	public void speak(String intro ) {
    System.out.println(intro);
	}
	
	public void jump(int meters) {
		System.out.println("I am jumping " + meters + " Meters in the air");
		
	}
	
	public void directionAndSpeed (String direction, int speed) {
		System.out.println("I am travelling " + direction + " At a rate of " + speed + "m/s");
		
	}
	public void movementPattern (String move)
	{
		System.out.println(move);
	}
}

public class MethodParameterPractice {

	public static void main(String[] args) {
		Machine bob = new Machine();
		bob.speak("Hello I am bob");
		
		bob.directionAndSpeed("west", 50);
		bob.movementPattern("Diamond");
		
		int value = 14;
		bob.jump(value);
		
		

	}

}
