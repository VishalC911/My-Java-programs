package JavaLearning;


public class BooleansMore {

	public static void main(String[] args) 
	{
		boolean passedDoor = true;
		boolean missedDoor = false;
		boolean passedAllDoors = false;
		int doorCount = 0;
		
		if ( passedDoor)
		{
		System.out.println("We pass the first door");	
		doorCount++;
		System.out.println(doorCount);
		}
		if (passedDoor)
		{
		System.out.println("We pass the second door");	
		doorCount++;
		System.out.println(doorCount);
		}
		if ( passedDoor)
		{
		System.out.println("We pass the third door");	
		doorCount++;
		System.out.println(doorCount);
		}
		if (doorCount == 3)
		{
			passedAllDoors = true;
			System.out.println("You Won");
		}
		else
		{
		System.out.println("You Lose");	
		}
	}

}
