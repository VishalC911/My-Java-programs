package JavaLearning;

public class MultidimentionalArrays
{

	public static void main(String[] args) 
	{
	int [] [] grid = { 
		{3,5, 2444},
		{2,4,1234},
		{1,2,3}  
					};
	
	System.out.println(grid [0][2]);
	
	String[][] text = {
			{"Bob", "Joe", "Dave"},
			{"a", "b", "c"},
			{"A", "B", "C"}
			
			
			
	};
	
	System.out.println(text[0][1]);
	
	
	String [][] texts = new String [2][2];
	
	texts [0][0] = "Billy";
	texts [0][1] = "Bob";
	texts [1][1] = "Joe";
	
	System.out.println( texts[0][1]);
	
	for (int row = 0; row< grid.length ; row++){
	
		for (int col = 0; col < grid [row].length; col++)  
		{ 
		System.out.print(grid [row] [col] + "\t");
		
		}
System.out.println();

	}
	

}
}
