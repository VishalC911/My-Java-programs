package JavaLearning;
import java.util.Scanner;

public class UserInput 
{

	public static void main(String[] args) 
	{
	Scanner input = new Scanner (System.in);
	
	System.out.println("Enter a number: ");
	
	int line = input.nextInt();
	
	
	
	if (line % 2 == 0 )
	{
		System.out.println("Even");	
	}
	 
	else
	{
		System.out.println("Odd");	
	}
	
	
	}

}
