package JavaLearning;

public class IfStatements {

	public static void main(String[] args)
	{
	int a = 20;
		
	if (a == 4)
	{
	System.out.print("Yes its true");
	}
	else if (a == 20)
	{
		System.out.print("This is 20");	
	}
	
	else
	{
		System.out.print("bruh");	
	}
	
	}
	

}
