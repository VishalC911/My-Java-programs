package JavaLearning;

import com.sun.beans.editors.DoubleEditor;

public class ConvertingNumberIntoString {

	public static void main(String[] args)
	{
		String num = "5.11";
		double num1 = Double.parseDouble(num);
		System.out.println(num1 + 5);
	}

}
