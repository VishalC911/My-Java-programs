package JavaLearning;

class Robot {
	public void speak(String text) {
		System.out.println(text);
	}
	public void jump(int height) {
		System.out.println("I am jumping " + height + " Meters");
	}
}

public class MethodParameters {

	public static void main(String[] args)
	{
     Robot sam = new Robot();
     sam.speak("Hi I am sam");
     sam.jump(6);
	}

}
