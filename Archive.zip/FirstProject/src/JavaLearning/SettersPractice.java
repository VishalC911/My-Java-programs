package JavaLearning;

class Lion {
	int age;
	String name;

	public String GetName() {

		return name;

	}

	public int GetAge() {

		return age;

	}

	public void SetName(String name) {
		this.name = name;
	}

	public void SetAge(int age) {
		this.age = age;

	}

}

public class SettersPractice {

	public static void main(String[] args) {

		Lion lion1 = new Lion();
		lion1.SetName("Joey");
		lion1.SetAge(15);

		System.out.println(lion1.GetName());
		System.out.println(lion1.GetAge());

	}

}
