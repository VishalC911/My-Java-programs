package JavaLearning;

class Frog {
	String name;
	int age;

	public void setName(String name) {
		this.name = name;
	}

	public int setAge(int age) {
		this.age = age - 10;
		
		return age;
	}

	public String getName(String name) {
		return name;
	}

	public int Getage() {
		return (age);
	}
}

public class Setters {

	public static void main(String[] args) {

		Frog frog1 = new Frog();
		
		//frog1.name = "bertie";

		frog1.setName("bertie");
		int value = frog1.setAge(5);
		System.out.println(value);
		frog1.getName("Jenny");
		

	}

}
