package JavaLearning;


public class ArrayOfStrings {

	public static void main(String[] args) 
	{
	String [] words = new String [3];
	words [0] = "Hello";
	words [1] = "My";
	words [2] = "Friend";
	
	System.out.print(words[1]);
	
	String [] fruits = {"apple", "bannana", "pear"};
	
	for (String fruit : fruits)
	{
	System.out.println( fruit);
	
	
	}
	
	
	}
    
	

}


