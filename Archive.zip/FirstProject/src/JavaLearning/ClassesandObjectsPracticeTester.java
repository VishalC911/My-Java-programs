package JavaLearning;

public class ClassesandObjectsPracticeTester {
private String color ="red";
int legs = 0;
public static void Sounds()
{
	 System.out.println("Bark");
}

String getColor() {
	
	 return color;
}

}



