package JavaLearning;

public class Strings {

	public static void main(String[] args) {
		String name = "Vishal Chandrasekar".substring(1, 10);
		System.out.println(name);
		int nameLeanth = name.length();
		System.out.println(nameLeanth);

		int lastName = "Julliet".indexOf("e");
		System.out.println(lastName);

	}

}
