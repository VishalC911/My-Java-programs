package JavaLearning;

import java.util.Scanner;

public class SwitchStatements {

	public static void main(String[] args)
	
	{
	Scanner input = new Scanner (System.in);
	
	System.out.println("Enter Password");
	String text = input.nextLine();
	
	switch(text) 
	{
	case "Annamalai9":
	
	System.out.println("You are logged in");
	
	break;
	
	default:
		System.out.println("Password Incorrect");
	}

	}

}
