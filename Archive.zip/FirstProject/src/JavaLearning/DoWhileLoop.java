package JavaLearning;

import java.util.Scanner;

public class DoWhileLoop {

	public static void main(String[] args) 
	
	{
	Scanner input = new Scanner (System.in);
	
	/* System.out.print ("Enter a number");
	
	int number = input.nextInt();
	
	while (number != 5)
	{
		System.out.print ("Enter a number");
		 number = input.nextInt();
	}
	*/
	int number = 0;
	do
	{
		 System.out.print ("Enter a number");
		  number = input.nextInt();
	}
	while (number != 5);
	
	System.out.print ("got it"); 

	}

}
