package JavaLearning;

public class ClassesandObjectsPractice {

	public static void main(String[] args) {
		ClassesandObjectsPracticeTester animal1 = new ClassesandObjectsPracticeTester();
		 String color = animal1.getColor();
		 System.out.println(color);
		 animal1.Sounds();
		
		// TODO Auto-generated method stub

	}

}
